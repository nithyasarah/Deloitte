package comm.dao.impl;

public class EmployeeDAOImpl {

}
