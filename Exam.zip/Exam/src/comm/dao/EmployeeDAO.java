package comm.dao;

public interface EmployeeDAO {

}
