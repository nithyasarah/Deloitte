package comm;

public class Employee {

}
